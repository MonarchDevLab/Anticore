=====================================================
ANTICORE - Portable (Kurulumsuz) Sürüm v0.3.0
Monolith Works // Sıfır Hız Kaybı ile DPI Atlatma
=====================================================
Kullanım:
1. 'Anticore.exe' dosyasına sağ tıklayıp 'Yönetici olarak çalıştır'ı seçin.
2. Başlat butonuna basın.
=====================================================
